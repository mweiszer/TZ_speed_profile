1. Datasets for different airports are recorded in separate files. E.g. file 'NKG.tra' corresponding to the NKG dataset.
2. In each file, the time-based taxi trajectory for an aircraft is recorded in one line.
3. The time-based taxi trajectory is described in the following format:
[aircraft id]: [control point id] [start of the arrival time interval] [end of the arrival time interval] [distance from the previous control point to the current one] ... 
